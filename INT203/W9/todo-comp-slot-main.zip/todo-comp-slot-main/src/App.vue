<script setup>
import TodoManager from './components/TodoManager.vue'
</script>

<template>
  <div class="w-full">

      <TodoManager />

  </div>
</template>

<style scoped></style>
